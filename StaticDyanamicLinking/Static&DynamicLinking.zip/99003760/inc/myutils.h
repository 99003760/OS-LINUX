#ifndef __MYUTIL_H
#define __MYUTIL_H

int factorial( int num ) ;

int checkPalindrome(int num) ;

int checkPrime(int num);

double vsum(int num ,...) ;

#endif