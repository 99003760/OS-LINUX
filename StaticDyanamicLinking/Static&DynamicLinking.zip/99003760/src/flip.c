#include "bitmask.h"

int flip_no(int num ,int  flippedNumb)
{
    flippedNumb = ~num ;
    return flippedNumb ;
}