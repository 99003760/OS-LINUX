#include<unistd.h>
#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void handler(int num)
{
    write(1,"Killed process\n",9);

}

int main()
{
    signal(SIGKILL,handler);
    while(1)
    {
        printf("welcome.. process ID= %d\n",getpid());
        sleep(1);
    }
}